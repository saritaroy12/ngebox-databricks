#import the required libraries
import boto3
import requests
import json
import time
import sys
import os

#get databricks access token from  secret manager
def get_access_token():
  DBToken = os.environ['DBTokenSecret']
  secret_arn = DBToken
  client = boto3.client('secretsmanager', region_name='us-east-1')
  response = client.get_secret_value(SecretId=secret_arn)
  secret_value = response['SecretString']
  return json.loads(secret_value)["Password"]
  
# get your input(event) data
def lambda_handler(event,context):
  hostname_url = os.environ['DBURL']
  print("Printing event object below")
  print(event) #Type(event) -> dict
  
  # Defining the hostname part of the URL depending upon the databricks version to be called
  databricks_hostname_dict = {
    "E2": hostname_url # E2 Hostname for test
  }
  
  # Handling defaults and missing hostname indicator
  if "hostname_key" not in event.keys():
    #hostname_key = "PVC"
    hostname_key = "E2"
  elif event["hostname_key"].upper() not in ["PVC","E2"]:
    #hostname_key = "PVC"
    hostname_key = "E2"
  else:
    hostname_key = event["hostname_key"]
    
  print(hostname_key)
  
  
  # Collecting event data in vars
  databricks_hostname = databricks_hostname_dict[hostname_key] # Selected hostname
  query_params = event['query_params'] if "query_params" in event.keys() else {}
  request_type = event['request_type'] if "request_type" in event.keys() else ""
  url = event['url'] if "url" in event.keys() else ""
  job_payload = event['job_payload'] if "job_payload" in event.keys() else {}
  print("job_payload_details")
  print(job_payload)
  
  if url == "" or request_type == "":
    print(event)
    return {"nge_box": {"status":1001, "message":"Not a valid input" + json.dumps(event)}}
    
  url = databricks_hostname + url
  
  # Predefined fixed vars
  #certificate="db-cert-pvc.crt" # Reqd for SSL authentication PVC
  #certificate="db-cert-e2-v1.crt" # Reqd for SSL authentication E2
  certificate="db-cert-e2-v2.crt" # Reqd for SSL authentication E2
  
  headers = {
    'Authorization': 'Bearer ' + get_access_token(),
    'Content-Type':'text/plain'
  }
  
  
  # Defining the query_params_str which is the part of url after the ? sign and has form of key1=val1&key2=val2...
  # Input taken from query_params dict
  query_params_str = ""
  if len(query_params) > 0:
    key_count = 1
    for querykey in query_params.keys():
      if key_count == 1:
        query_params_str = "?" + querykey + "=" + query_params[querykey]
      else:
        query_params_str = "&" + querykey + "=" + query_params[querykey]
   
  if request_type == "POST":  #Calling the POST method syntax
    resp = requests.post(
      url + query_params_str, 
      headers=headers,
      verify=certificate, 
       json=job_payload
      )
  elif request_type == "GET":  #Calling the GET method syntax
    resp = requests.get(
        url + query_params_str, 
        headers=headers,
        verify=certificate,
        json=job_payload
        )
    
  else:
    resp = "Unknown Request method: GET/POST?"
  resp_body = resp.text
  # Since returned ContentType is text/plain, so converting to readable json
  resp_json = json.loads(resp.text) 
  print("Printing the resp_json after transforming text response to json")
  print (resp_json)
  print (type(resp_json))
  
  return {"data":resp_json, "status_code":resp.status_code}  
