#import the required libraries
import json
import boto3
import time
import uuid
import ast 
import os

#define lambda handler (event input)
def lambda_handler(event, context):
    client = boto3.client('lambda')
    Rest_API = os.environ['RestApiLambdaName']
    client = boto3.client('lambda')
    sts = boto3.client('sts')
    response = sts.get_caller_identity()
    account_id = response['Account']
    print(account_id)    
    job_id = event['job_id']   
    usecase_id = event['usecase_id']
    Mapping_Params = event['Mapping_Params']
    job_parameters = {
        'job_id': job_id,
        'usecase_id': usecase_id,
        'Mapping_Params': Mapping_Params
    }
    
    # Definition of API endpoints, the prefix hostname is defined in NGE-Box-Rest-Api-Lambda
    job_run_api = '/api/2.1/jobs/run-now'
    job_status_get_api = '/api/2.1/jobs/runs/get'
    job_output_get_api = '/api/2.0/jobs/runs/get-output'

    FunctionName = 'arn:aws:lambda:us-east-1:'+account_id+':function:'+Rest_API
    updated_arn = FunctionName.replace('account_id', account_id)
    print(updated_arn)    
    
    # Input parameters to run job
    inputParams = { 
     "url":job_run_api, 
     "request_type":"POST",
     "query_params":{}, 
     "job_payload":{"job_id":job_id,'notebook_params': job_parameters},
     "hostname_key": "E2",
     "headers":{}
    }
    print('inputdata')
    print(inputParams)
    #Invocation of rest API to run the job
    response = client.invoke(
     FunctionName = updated_arn,
     InvocationType = 'RequestResponse',
     Payload = json.dumps(inputParams)
     )
    job_run_output = json.loads(response['Payload'].read())
    print(job_run_output)
    
    #{'data': {'run_id': 345425487, 'number_in_job': 345425487}, 'status_code': 200}
    run_id = job_run_output["data"]["run_id"]
    job_run_status_code = job_run_output["status_code"]
    print(run_id)
    print(job_run_status_code)
    
    if job_run_status_code == 200 :
     # Input parameters to get status of job
     task_lifecycle_state = "PENDING"
     while task_lifecycle_state not in ["TERMINATED"]:
      inputParams = { 
       "url":job_status_get_api, 
       "request_type":"GET",
       "query_params":{"run_id":str(run_id)}, 
       "job_payload":{}, 
       "hostname_key": "E2",
       "headers":{}
      }
      #Invocation of rest API to get status of  the job 
      response = client.invoke(
       FunctionName = updated_arn,
       InvocationType = 'RequestResponse',
       Payload = json.dumps(inputParams)
       )
      response_json = json.loads(response['Payload'].read())
      print(response_json)
      
      if response_json["status_code"] != 200:
       break
      
      task_state = response_json["data"]["tasks"][0]["state"]
      task_lifecycle_state = task_state["life_cycle_state"]
      print(task_state)
      print(task_lifecycle_state)
      
      if "result_state" in task_state.keys():
       task_result_state = task_state["result_state"]
       break
      
      time.sleep(5)
      
     print(task_result_state)
     
     #if lifecycle is "TERMINATED" and "SUCCESS" get the output of job 
     if task_lifecycle_state == "TERMINATED" and task_result_state == "SUCCESS" :
      inputParams = { 
      "url":job_output_get_api, 
      "request_type":"GET",
      "query_params":{"run_id":str(run_id)}, 
      "job_payload":{}, 
      "hostname_key": "E2",
      "headers":{}
     }
     
     #Invocation of rest API to get output of  the job 
     response = client.invoke(
      FunctionName = updated_arn,
      InvocationType = 'RequestResponse',
      Payload = json.dumps(inputParams)
      )
     job_get_output = json.loads(response['Payload'].read())
     job_status = job_get_output["status_code"]
     metadata_json_result = job_get_output["data"]["metadata"]["job_id"]
     job_name = job_get_output["data"]["metadata"]["run_name"]
     #print the output
     resp = {
      "usecase_id": usecase_id,
      "job_id": metadata_json_result,
      "Job_Name":job_name,
      "job_status": job_status
        }
     print(job_get_output)
     print(job_status)
     print(metadata_json_result)
     return (resp)
