#import the required libraries
import json
import boto3
import time
import os

#define lambda handler (event input)
def lambda_handler(event, context):
    cluster_id = os.environ['ClusterId']
    Rest_API = os.environ['RestApiLambdaName']
    client = boto3.client('lambda')
    sts = boto3.client('sts')
    response = sts.get_caller_identity()
    account_id = response['Account']
    print(account_id)  
    
    
    # Definition of API endpoints, the prefix hostname is defined in NGE-Box-Rest-Api-Lambda
    cluster_status_api = '/api/2.0/clusters/get'
    cluster_start_api = '/api/2.0/clusters/start'
    FunctionName = 'arn:aws:lambda:us-east-1:'+account_id+':function:'+Rest_API
    updated_arn = FunctionName.replace('account_id', account_id)
    print(updated_arn)
    
    # Input parameters to get the status of databricks cluster
    inputParams = { 
     "url":cluster_status_api, 
     "request_type":"GET",
     "query_params":{}, 
     "job_payload":{"cluster_id":cluster_id}, 
     "hostname_key": "E2",
     "headers":{}
    }
    
    # Invocation of rest-api-lambda to get cluster status
    response = client.invoke(
     FunctionName = updated_arn,
     InvocationType = 'RequestResponse',
     Payload = json.dumps(inputParams)
     )
    cluster_status_output = json.loads(response['Payload'].read())
    print(cluster_status_output)
    cluster_status = cluster_status_output["data"]["state"]
    cluster_status_code =cluster_status_output["status_code"]
    print(cluster_status)

    # Invocation of rest-api-lambda to start the cluster in case of "TERMINATED" state
    if cluster_status == "TERMINATED":
      inputParams = { 
       "url":cluster_start_api, 
       "request_type":"POST",
       "job_payload":{"cluster_id":cluster_id},
       "query_params":{}, 
       "hostname_key": "E2",
       "headers":{}
      }
       
      response = client.invoke(
       FunctionName = updated_arn,
       InvocationType = 'RequestResponse',
       Payload = json.dumps(inputParams)
       )
      cluster_start_output = json.loads(response['Payload'].read())
      print(cluster_start_output)
      cluster_start_status = cluster_start_output["status_code"]
      print(cluster_start_status)
      
      # if cluster started succesfull wait till it attains "RUNNING" state
      if cluster_start_status == 200 :
        cluster_status = "PENDING"
        while cluster_status not in ["RUNNING"]:
         inputParams = { 
          "url":cluster_status_api,
          "request_type":"GET",
          "query_params":{},
          "job_payload":{"cluster_id":cluster_id},
          "hostname_key": "E2",
          "headers":{}
          }
         response = client.invoke(
          FunctionName = updated_arn,
          InvocationType = 'RequestResponse',
          Payload = json.dumps(inputParams)
          )
         cluster_status_output = json.loads(response['Payload'].read())
         print(cluster_status_output)
         cluster_status_code =cluster_status_output["status_code"]
         
         if cluster_status_code != 200:
          break
         
         cluster_status = cluster_status_output["data"]["state"]
         print(cluster_status) 
         
         #if the cluster is is "RUNNING" state break and print the success output
         if cluster_status == "RUNNING":
          break
         time.sleep(20)
         
        response = {
        "cluster_message_status":"cluster is in active state",
        "cluster_start_status": cluster_status_code
         }
         
      else:
       # if the cluster hasn't succesfully started the cluster print the error output
       response = {"Task_status":"Failed" }
      print(cluster_start_output)
      
    else:
     # if the cluster is not in "TERMINATED" state print the success output
     response = {
       "cluster_message_status":"cluster is in active state",
       "cluster_start_status": cluster_status_code
        }
        
    return(response)
